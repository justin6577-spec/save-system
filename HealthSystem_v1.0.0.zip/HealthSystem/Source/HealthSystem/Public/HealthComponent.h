#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "HealthSystemTypes.h"
#include "HealthComponent.generated.h"

/**
 * Attach to any actor to give it health, armor, damage handling, and death.
 * Blueprint-ready — all functions are BlueprintCallable.
 */
UCLASS(ClassGroup=(HealthSystem), meta=(BlueprintSpawnableComponent))
class HEALTHSYSTEM_API UHealthComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UHealthComponent();

    /* ── Configuration ── */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health")
    float MaxHealth = 100.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health")
    float MaxArmor = 0.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health|Regen")
    float HealthRegenPerSecond = 0.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health|Regen")
    float RegenDelayAfterDamage = 2.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health")
    bool bCanRevive = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health")
    float ReviveHealthPercent = 0.3f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health|Armor")
    float ArmorDamageReduction = 0.5f; // 50% damage goes to armor

    /* ── Damage/Heal ── */
    UFUNCTION(BlueprintCallable, Category = "Health")
    void TakeDamage(float Amount, EHealthDamageType Type = EHealthDamageType::Physical, AActor* InstigatorActor = nullptr);

    UFUNCTION(BlueprintCallable, Category = "Health")
    void Heal(float Amount);

    UFUNCTION(BlueprintCallable, Category = "Health")
    void Revive();

    UFUNCTION(BlueprintCallable, Category = "Health")
    void SetHealthRegenEnabled(bool bEnabled);

    /* ── Queries ── */
    UFUNCTION(BlueprintPure, Category = "Health")
    float GetHealth() const { return CurrentHealth; }

    UFUNCTION(BlueprintPure, Category = "Health")
    float GetHealthPercent() const { return MaxHealth > 0 ? CurrentHealth / MaxHealth : 0; }

    UFUNCTION(BlueprintPure, Category = "Health")
    float GetArmor() const { return CurrentArmor; }

    UFUNCTION(BlueprintPure, Category = "Health")
    float GetArmorPercent() const { return MaxArmor > 0 ? CurrentArmor / MaxArmor : 0; }

    UFUNCTION(BlueprintPure, Category = "Health")
    bool IsDead() const { return DeathState != EHealthDeathState::Alive; }

    UFUNCTION(BlueprintPure, Category = "Health")
    bool IsAlive() const { return DeathState == EHealthDeathState::Alive; }

    UFUNCTION(BlueprintPure, Category = "Health")
    EHealthDeathState GetDeathState() const { return DeathState; }

    /* ── Events ── */
    UPROPERTY(BlueprintAssignable, Category = "Health|Events")
    FOnHealthDamaged OnDamaged;

    UPROPERTY(BlueprintAssignable, Category = "Health|Events")
    FOnHealthChanged OnHealthChanged;

    UPROPERTY(BlueprintAssignable, Category = "Health|Events")
    FOnHealthDeath OnDeath;

    UPROPERTY(BlueprintAssignable, Category = "Health|Events")
    FOnHealthRevived OnRevived;

    UPROPERTY(BlueprintAssignable, Category = "Health|Events")
    FOnArmorChanged OnArmorChanged;

    UPROPERTY(BlueprintAssignable, Category = "Health|Events")
    FOnShieldBroke OnShieldBroke;

protected:
    virtual void BeginPlay() override;
    virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
    float CurrentHealth = 100.0f;
    float CurrentArmor = 0.0f;
    EHealthDeathState DeathState = EHealthDeathState::Alive;
    float TimeSinceLastDamage = 999.0f;
    bool bRegenActive = true;
    bool bShieldBrokeBroadcasted = false;
};
