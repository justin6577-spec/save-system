#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "HealthBarWidget.generated.h"

/**
 * Base health bar widget. Bind to a UHealthComponent and it auto-updates.
 * Override UpdateDisplay in Blueprint for custom visuals.
 */
UCLASS()
class HEALTHSYSTEM_API UHealthBarWidget : public UUserWidget
{
    GENERATED_BODY()

public:
    /** Bind this widget to a health component. Auto-subscribes to events. */
    UFUNCTION(BlueprintCallable, Category = "Health|UI")
    void BindToHealthComponent(class UHealthComponent* InHealthComp);

    /** Current health percent (0.0 - 1.0). Bind your progress bar to this. */
    UFUNCTION(BlueprintPure, Category = "Health|UI")
    float GetHealthPercent() const { return HealthPercent; }

    /** Current armor percent (0.0 - 1.0). */
    UFUNCTION(BlueprintPure, Category = "Health|UI")
    float GetArmorPercent() const { return ArmorPercent; }

    /** Is the owner dead? */
    UFUNCTION(BlueprintPure, Category = "Health|UI")
    bool IsOwnerDead() const { return bOwnerDead; }

    /** Show/hide this widget. Use for fading on damage. */
    UFUNCTION(BlueprintCallable, Category = "Health|UI")
    void SetBarVisible(bool bVisible);

    /** Override in Blueprint to update visuals when values change. */
    UFUNCTION(BlueprintImplementableEvent, Category = "Health|UI")
    void OnValuesUpdated();

protected:
    UFUNCTION()
    void HandleHealthChanged(float CurrentHealth, float MaxHealth);

    UFUNCTION()
    void HandleArmorChanged(float CurrentArmor, float MaxArmor);

    UFUNCTION()
    void HandleDeath();

    UFUNCTION()
    void HandleRevived();

    UPROPERTY(BlueprintReadOnly, Category = "Health|UI")
    float HealthPercent = 1.0f;

    UPROPERTY(BlueprintReadOnly, Category = "Health|UI")
    float ArmorPercent = 0.0f;

    UPROPERTY(BlueprintReadOnly, Category = "Health|UI")
    bool bOwnerDead = false;

    UPROPERTY()
    TWeakObjectPtr<UHealthComponent> BoundHealthComponent;
};
