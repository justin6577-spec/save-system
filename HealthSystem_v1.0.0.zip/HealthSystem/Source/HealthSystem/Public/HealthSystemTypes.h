#pragma once

#include "CoreMinimal.h"
#include "HealthSystemTypes.generated.h"

/** Damage type categories. Can be extended. */
UENUM(BlueprintType)
enum class EHealthDamageType : uint8
{
    Physical    UMETA(DisplayName = "Physical"),
    Fire        UMETA(DisplayName = "Fire"),
    Ice         UMETA(DisplayName = "Ice"),
    Poison      UMETA(DisplayName = "Poison"),
    Lightning   UMETA(DisplayName = "Lightning"),
    TrueDamage  UMETA(DisplayName = "True Damage (Ignores Armor)")
};

/** Death state for any damageable actor. */
UENUM(BlueprintType)
enum class EHealthDeathState : uint8
{
    Alive       UMETA(DisplayName = "Alive"),
    Dying       UMETA(DisplayName = "Dying"),
    Dead        UMETA(DisplayName = "Dead")
};

/** Damage event data passed through the pipeline. */
USTRUCT(BlueprintType)
struct FHealthDamageEvent
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadWrite)
    float RawDamage = 0.0f;

    UPROPERTY(BlueprintReadWrite)
    float FinalDamage = 0.0f;

    UPROPERTY(BlueprintReadWrite)
    EHealthDamageType DamageType = EHealthDamageType::Physical;

    UPROPERTY(BlueprintReadWrite)
    AActor* Instigator = nullptr;

    UPROPERTY(BlueprintReadWrite)
    bool bWasCrit = false;

    UPROPERTY(BlueprintReadWrite)
    bool bKilled = false;
};

/** Delegate: damage received. */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnHealthDamaged, const FHealthDamageEvent&, DamageEvent);

/** Delegate: health changed (heal or damage). */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnHealthChanged, float, CurrentHealth, float, MaxHealth);

/** Delegate: death occurred. */
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnHealthDeath);

/** Delegate: revived. */
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnHealthRevived);

/** Delegate: armor changed. */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnArmorChanged, float, CurrentArmor, float, MaxArmor);

/** Delegate: shield broke. */
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnShieldBroke);
