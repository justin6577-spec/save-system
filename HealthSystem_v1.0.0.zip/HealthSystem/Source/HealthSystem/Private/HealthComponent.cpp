#include "HealthComponent.h"

UHealthComponent::UHealthComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
    CurrentHealth = MaxHealth;
    CurrentArmor = MaxArmor;
}

void UHealthComponent::BeginPlay()
{
    Super::BeginPlay();
    CurrentHealth = MaxHealth;
    CurrentArmor = MaxArmor;
}

void UHealthComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    if (DeathState != EHealthDeathState::Alive)
    {
        return;
    }

    TimeSinceLastDamage += DeltaTime;

    // Health regeneration
    if (bRegenActive && HealthRegenPerSecond > 0.0f && TimeSinceLastDamage >= RegenDelayAfterDamage)
    {
        Heal(HealthRegenPerSecond * DeltaTime);
    }
}

void UHealthComponent::TakeDamage(float Amount, EHealthDamageType Type, AActor* InstigatorActor)
{
    if (DeathState != EHealthDeathState::Alive || Amount <= 0.0f)
    {
        return;
    }

    float RemainingDamage = Amount;

    // True damage bypasses armor
    if (Type != EHealthDamageType::TrueDamage && CurrentArmor > 0.0f)
    {
        const float ArmorAbsorb = FMath::Min(CurrentArmor, RemainingDamage * ArmorDamageReduction);
        CurrentArmor -= ArmorAbsorb;
        RemainingDamage -= ArmorAbsorb;
        OnArmorChanged.Broadcast(CurrentArmor, MaxArmor);

        if (CurrentArmor <= 0.0f && !bShieldBrokeBroadcasted)
        {
            bShieldBrokeBroadcasted = true;
            CurrentArmor = 0.0f;
            OnShieldBroke.Broadcast();
        }
    }

    // Apply to health
    if (RemainingDamage > 0.0f)
    {
        CurrentHealth = FMath::Max(0.0f, CurrentHealth - RemainingDamage);
        TimeSinceLastDamage = 0.0f;
        OnHealthChanged.Broadcast(CurrentHealth, MaxHealth);

        FHealthDamageEvent Event;
        Event.RawDamage = Amount;
        Event.FinalDamage = RemainingDamage;
        Event.DamageType = Type;
        Event.Instigator = InstigatorActor;
        Event.bKilled = CurrentHealth <= 0.0f;
        OnDamaged.Broadcast(Event);

        if (CurrentHealth <= 0.0f)
        {
            DeathState = EHealthDeathState::Dead;
            OnDeath.Broadcast();
        }
    }
}

void UHealthComponent::Heal(float Amount)
{
    if (DeathState != EHealthDeathState::Alive || Amount <= 0.0f)
    {
        return;
    }

    CurrentHealth = FMath::Min(MaxHealth, CurrentHealth + Amount);
    OnHealthChanged.Broadcast(CurrentHealth, MaxHealth);
}

void UHealthComponent::Revive()
{
    if (DeathState == EHealthDeathState::Alive || !bCanRevive)
    {
        return;
    }

    DeathState = EHealthDeathState::Alive;
    CurrentHealth = MaxHealth * ReviveHealthPercent;
    CurrentArmor = MaxArmor;
    bShieldBrokeBroadcasted = false;
    TimeSinceLastDamage = RegenDelayAfterDamage;
    OnHealthChanged.Broadcast(CurrentHealth, MaxHealth);
    OnRevived.Broadcast();
}

void UHealthComponent::SetHealthRegenEnabled(bool bEnabled)
{
    bRegenActive = bEnabled;
}
