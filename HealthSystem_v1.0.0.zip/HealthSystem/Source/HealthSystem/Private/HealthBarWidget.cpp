#include "HealthBarWidget.h"
#include "HealthComponent.h"

void UHealthBarWidget::BindToHealthComponent(UHealthComponent* InHealthComp)
{
    if (!InHealthComp)
    {
        return;
    }

    BoundHealthComponent = InHealthComp;

    InHealthComp->OnHealthChanged.AddDynamic(this, &UHealthBarWidget::HandleHealthChanged);
    InHealthComp->OnArmorChanged.AddDynamic(this, &UHealthBarWidget::HandleArmorChanged);
    InHealthComp->OnDeath.AddDynamic(this, &UHealthBarWidget::HandleDeath);
    InHealthComp->OnRevived.AddDynamic(this, &UHealthBarWidget::HandleRevived);

    // Initial values
    HealthPercent = InHealthComp->GetHealthPercent();
    ArmorPercent = InHealthComp->GetArmorPercent();
    bOwnerDead = InHealthComp->IsDead();
    OnValuesUpdated();
}

void UHealthBarWidget::HandleHealthChanged(float CurrentHealth, float MaxHealth)
{
    HealthPercent = MaxHealth > 0.0f ? CurrentHealth / MaxHealth : 0.0f;
    OnValuesUpdated();
}

void UHealthBarWidget::HandleArmorChanged(float CurrentArmor, float MaxArmor)
{
    ArmorPercent = MaxArmor > 0.0f ? CurrentArmor / MaxArmor : 0.0f;
    OnValuesUpdated();
}

void UHealthBarWidget::HandleDeath()
{
    bOwnerDead = true;
    HealthPercent = 0.0f;
    OnValuesUpdated();
}

void UHealthBarWidget::HandleRevived()
{
    bOwnerDead = false;
    OnValuesUpdated();
}

void UHealthBarWidget::SetBarVisible(bool bVisible)
{
    SetVisibility(bVisible ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
}
