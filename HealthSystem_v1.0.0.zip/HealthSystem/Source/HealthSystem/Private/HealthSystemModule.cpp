#include "HealthSystem.h"

void FHealthSystemModule::StartupModule() {}
void FHealthSystemModule::ShutdownModule() {}

IMPLEMENT_MODULE(FHealthSystemModule, HealthSystem)
