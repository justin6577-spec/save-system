# Health & Damage System — UE5 Health Plugin

**v1.0.0 | UE5.4–5.8 | Blueprint + C++**

## What It Does
Drop-in health component. Attach to any actor for full health + armor + damage + regen + death handling. Includes auto-binding health bar widget.

## Features
- **UHealthComponent** — attach to any actor, instant health system
- **5 damage types** — Physical, Fire, Ice, Poison, Lightning, True Damage
- **Armor system** — configurable damage absorption, shield break events
- **Health regen** — per-second regen with configurable delay after damage
- **Death & revive** — Death/Dying/Alive states, optional revive
- **7 Blueprint events** — OnDamaged, OnHealthChanged, OnDeath, OnRevived, OnArmorChanged, OnShieldBroke
- **Health bar widget** — auto-binds to health component, BlueprintImplementableEvent for custom visuals
- **UE5.8 compiled** — 0 errors, 0 warnings

## Quick Start
```
// Attach UHealthComponent to any actor
HealthComp->TakeDamage(25.0f, EHealthDamageType::Fire, Attacker);
HealthComp->Heal(10.0f);

// Bind UI
HealthBar->BindToHealthComponent(HealthComp);
```

## API
| Function | Description |
|---|---|
| TakeDamage(Amount, Type, Instigator) | Deal damage with type |
| Heal(Amount) | Restore health |
| Revive() | Bring back from dead |
| GetHealth() / GetHealthPercent() | Current health |
| GetArmor() / GetArmorPercent() | Current armor |
| IsDead() / IsAlive() | Death check |
| SetHealthRegenEnabled(bool) | Toggle regen |
| BindToHealthComponent() | Wire up health bar |

## Requirements
- UE 5.4–5.8 | C++20 | No dependencies
