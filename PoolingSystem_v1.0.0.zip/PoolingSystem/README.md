# PoolingSystem — UE5 Object & Actor Pooling

**Version 1.0.0 | UE5.4–5.8 | Blueprint + C++**

## What It Does
High-performance object pooling for Unreal Engine 5. Stop spawning/destroying actors — reuse them. Includes both generic `UObjectPool` and `UActorPool` with auto-warmup, lifecycle events, and full Blueprint support.

## Features
- **Actor Pool** — pool any AActor (projectiles, enemies, VFX, pickups)
- **Object Pool** — pool any UObject subclass
- **Auto-warmup** — pre-spawn N actors at init time
- **Lifecycle events** — OnActorSpawned / OnActorReturned delegates
- **Smart reuse** — validates pooled objects, skips garbage-collected ones
- **Configurable** — max capacity, auto-activate, hide-on-return
- **Blueprint-ready** — all functions BlueprintCallable
- **UE5.8 compiled & verified** — 0 errors, 0 warnings

## Quick Start
```
UActorPool* BulletPool = NewObject<UActorPool>();
BulletPool->Initialize(ABullet::StaticClass(), 50, 200);

AActor* Bullet = BulletPool->GetActorAt(SpawnLoc, SpawnRot);
BulletPool->ReturnActor(Bullet);
```

## API
| Function | Description |
|---|---|
| Initialize(Class, Initial, Max) | Set up pool with actor class and capacity |
| GetActor() | Get from pool (or spawn new) |
| GetActorAt(Location, Rotation) | Get + position |
| GetActorAtTransform(Transform) | Get + full transform |
| ReturnActor(Actor) | Return to pool for reuse |
| Warmup(Count) | Pre-spawn N actors |
| Clear() | Destroy all + empty pool |
| GetAvailableCount() | Pooled + ready |
| GetInUseCount() | Currently active |
| GetTotalAllocated() | Total ever spawned |

## Requirements
- UE 5.4–5.8
- C++20
- No dependencies
