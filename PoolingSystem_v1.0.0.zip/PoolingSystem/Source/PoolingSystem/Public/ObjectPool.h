#pragma once

#include "CoreMinimal.h"
#include "ObjectPool.generated.h"

/**
 * Generic typed object pool.
 * Use for subclasses you don't want to GC/recreate constantly.
 * Template param must derive from UObject.
 */
UCLASS(BlueprintType)
class POOLINGSYSTEM_API UObjectPool : public UObject
{
    GENERATED_BODY()

public:
    /** Initialize pool with object class and capacity. Call once. */
    UFUNCTION(BlueprintCallable, Category = "Pooling")
    void Initialize(TSubclassOf<UObject> InObjectClass, int32 InitialCapacity = 16, int32 MaxCapacity = 256);

    /** Get an object from the pool. Creates new if empty and under max. */
    UFUNCTION(BlueprintCallable, Category = "Pooling")
    UObject* Get();

    /** Return an object to the pool for reuse. */
    UFUNCTION(BlueprintCallable, Category = "Pooling")
    void Return(UObject* Object);

    /** Pre-warm the pool by creating N objects ahead of time. */
    UFUNCTION(BlueprintCallable, Category = "Pooling")
    void Warmup(int32 Count);

    /** Destroy all pooled objects and empty the pool. */
    UFUNCTION(BlueprintCallable, Category = "Pooling")
    void Clear();

    /** Number of objects currently available in the pool. */
    UFUNCTION(BlueprintPure, Category = "Pooling")
    int32 GetAvailableCount() const { return AvailableObjects.Num(); }

    /** Total objects allocated (in pool + in use). */
    UFUNCTION(BlueprintPure, Category = "Pooling")
    int32 GetTotalAllocated() const { return TotalAllocated; }

private:
    UPROPERTY()
    TSubclassOf<UObject> ObjectClass;

    UPROPERTY()
    TArray<UObject*> AvailableObjects;

    int32 MaxCapacity = 256;
    int32 TotalAllocated = 0;
};
