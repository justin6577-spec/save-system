#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ActorPool.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnPooledActorSpawned, AActor*, Actor);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnPooledActorReturned, AActor*, Actor);

/**
 * High-performance actor pool. Spawn actors once, reuse forever.
 * Ideal for projectiles, enemies, VFX, pickups — anything spawned frequently.
 *
 * Usage:
 *   Pool->Warmup(50);
 *   AActor* Bullet = Pool->GetActor();
 *   Pool->ReturnActor(Bullet);
 */
UCLASS(BlueprintType)
class POOLINGSYSTEM_API UActorPool : public UObject
{
    GENERATED_BODY()

public:
    /** Initialize the pool with an actor class. */
    UFUNCTION(BlueprintCallable, Category = "Pooling|Actor")
    void Initialize(TSubclassOf<AActor> InActorClass, int32 InitialCapacity = 16, int32 MaxCapacity = 256);

    /** Get a pooled actor. Returns nullptr if pool is exhausted. */
    UFUNCTION(BlueprintCallable, Category = "Pooling|Actor")
    AActor* GetActor();

    /** Get a pooled actor at a specific transform. */
    UFUNCTION(BlueprintCallable, Category = "Pooling|Actor")
    AActor* GetActorAtTransform(FTransform SpawnTransform);

    /** Get a pooled actor at location and rotation. */
    UFUNCTION(BlueprintCallable, Category = "Pooling|Actor")
    AActor* GetActorAt(FVector Location, FRotator Rotation);

    /** Return an actor to the pool. */
    UFUNCTION(BlueprintCallable, Category = "Pooling|Actor")
    void ReturnActor(AActor* Actor);

    /** Pre-spawn N actors into the pool. */
    UFUNCTION(BlueprintCallable, Category = "Pooling|Actor")
    void Warmup(int32 Count);

    /** Destroy all pooled actors and empty the pool. */
    UFUNCTION(BlueprintCallable, Category = "Pooling|Actor")
    void Clear();

    /** Number of actors available in the pool right now. */
    UFUNCTION(BlueprintPure, Category = "Pooling|Actor")
    int32 GetAvailableCount() const { return AvailableActors.Num(); }

    /** Total actors this pool has allocated. */
    UFUNCTION(BlueprintPure, Category = "Pooling|Actor")
    int32 GetTotalAllocated() const { return TotalAllocated; }

    /** Number of actors currently in use (not in pool). */
    UFUNCTION(BlueprintPure, Category = "Pooling|Actor")
    int32 GetInUseCount() const { return TotalAllocated - AvailableActors.Num(); }

    /** Called when an actor is taken from the pool. */
    UPROPERTY(BlueprintAssignable, Category = "Pooling|Actor")
    FOnPooledActorSpawned OnActorSpawned;

    /** Called when an actor is returned to the pool. */
    UPROPERTY(BlueprintAssignable, Category = "Pooling|Actor")
    FOnPooledActorReturned OnActorReturned;

    /** Should actors auto-activate when taken from pool? Default: true. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pooling|Actor")
    bool bAutoActivateOnGet = true;

    /** Should returned actors be hidden? Default: true. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pooling|Actor")
    bool bHideOnReturn = true;

private:
    UPROPERTY()
    TSubclassOf<AActor> ActorClass;

    UPROPERTY()
    TArray<AActor*> AvailableActors;

    UPROPERTY()
    UWorld* CachedWorld = nullptr;

    int32 MaxCapacity = 256;
    int32 TotalAllocated = 0;

    AActor* SpawnNewActor();
    void ActivateActor(AActor* Actor);
    void DeactivateActor(AActor* Actor);
};
