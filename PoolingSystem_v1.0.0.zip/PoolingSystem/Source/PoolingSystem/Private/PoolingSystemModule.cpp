#include "PoolingSystem.h"

void FPoolingSystemModule::StartupModule() {}
void FPoolingSystemModule::ShutdownModule() {}

IMPLEMENT_MODULE(FPoolingSystemModule, PoolingSystem)
