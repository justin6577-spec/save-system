#include "ObjectPool.h"

void UObjectPool::Initialize(TSubclassOf<UObject> InObjectClass, int32 InitialCapacity, int32 InMaxCapacity)
{
    ObjectClass = InObjectClass;
    MaxCapacity = FMath::Max(1, InMaxCapacity);
    if (InitialCapacity > 0)
    {
        Warmup(InitialCapacity);
    }
}

UObject* UObjectPool::Get()
{
    // Reuse from pool
    while (AvailableObjects.Num() > 0)
    {
        UObject* Obj = AvailableObjects.Pop(EAllowShrinking::No);
        if (IsValid(Obj))
        {
            return Obj;
        }
        TotalAllocated--;
    }

    // Create new if under max
    if (TotalAllocated < MaxCapacity && ObjectClass)
    {
        UObject* NewObj = NewObject<UObject>(this, ObjectClass);
        if (NewObj)
        {
            TotalAllocated++;
            return NewObj;
        }
    }

    return nullptr; // Pool exhausted
}

void UObjectPool::Return(UObject* Object)
{
    if (!Object || AvailableObjects.Num() >= MaxCapacity)
    {
        return;
    }
    AvailableObjects.Add(Object);
}

void UObjectPool::Warmup(int32 Count)
{
    const int32 Remaining = MaxCapacity - TotalAllocated;
    const int32 ToCreate = FMath::Min(Count, Remaining);
    
    for (int32 i = 0; i < ToCreate; ++i)
    {
        if (ObjectClass)
        {
            UObject* Obj = NewObject<UObject>(this, ObjectClass);
            if (Obj)
            {
                AvailableObjects.Add(Obj);
                TotalAllocated++;
            }
        }
    }
}

void UObjectPool::Clear()
{
    for (UObject* Obj : AvailableObjects)
    {
        if (IsValid(Obj))
        {
            Obj->ConditionalBeginDestroy();
        }
    }
    AvailableObjects.Empty();
    TotalAllocated = 0;
}
