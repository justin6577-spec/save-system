#include "ActorPool.h"
#include "Engine/World.h"

void UActorPool::Initialize(TSubclassOf<AActor> InActorClass, int32 InitialCapacity, int32 InMaxCapacity)
{
    ActorClass = InActorClass;
    MaxCapacity = FMath::Max(1, InMaxCapacity);
    
    if (InitialCapacity > 0)
    {
        Warmup(InitialCapacity);
    }
}

AActor* UActorPool::SpawnNewActor()
{
    if (!ActorClass)
    {
        return nullptr;
    }

    UWorld* World = CachedWorld;
    if (!World)
    {
        // Try to get the world from the outer
        World = GetWorld();
        CachedWorld = World;
    }
    
    if (!World)
    {
        return nullptr;
    }

    FActorSpawnParameters SpawnParams;
    SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
    SpawnParams.ObjectFlags |= RF_Transient; // Don't save pooled actors
    
    AActor* NewActor = World->SpawnActor<AActor>(ActorClass, FTransform::Identity, SpawnParams);
    if (NewActor)
    {
        TotalAllocated++;
        DeactivateActor(NewActor);
    }
    
    return NewActor;
}

void UActorPool::ActivateActor(AActor* Actor)
{
    if (!Actor)
    {
        return;
    }
    
    Actor->SetActorHiddenInGame(false);
    Actor->SetActorEnableCollision(true);
    Actor->SetActorTickEnabled(true);
    
    if (bAutoActivateOnGet)
    {
        Actor->SetActorTickEnabled(true);
    }
}

void UActorPool::DeactivateActor(AActor* Actor)
{
    if (!Actor)
    {
        return;
    }
    
    Actor->SetActorTickEnabled(false);
    Actor->SetActorEnableCollision(false);
    
    if (bHideOnReturn)
    {
        Actor->SetActorHiddenInGame(true);
    }
}

AActor* UActorPool::GetActor()
{
    return GetActorAtTransform(FTransform::Identity);
}

AActor* UActorPool::GetActorAtTransform(FTransform SpawnTransform)
{
    // Reuse from pool
    while (AvailableActors.Num() > 0)
    {
        AActor* Actor = AvailableActors.Pop(EAllowShrinking::No);
        if (IsValid(Actor))
        {
            Actor->SetActorTransform(SpawnTransform, false, nullptr, ETeleportType::TeleportPhysics);
            ActivateActor(Actor);
            OnActorSpawned.Broadcast(Actor);
            return Actor;
        }
        TotalAllocated--;
    }

    // Create new
    AActor* NewActor = SpawnNewActor();
    if (NewActor)
    {
        NewActor->SetActorTransform(SpawnTransform, false, nullptr, ETeleportType::TeleportPhysics);
        ActivateActor(NewActor);
        OnActorSpawned.Broadcast(NewActor);
        return NewActor;
    }

    return nullptr;
}

AActor* UActorPool::GetActorAt(FVector Location, FRotator Rotation)
{
    return GetActorAtTransform(FTransform(Rotation, Location));
}

void UActorPool::ReturnActor(AActor* Actor)
{
    if (!Actor || AvailableActors.Num() >= MaxCapacity)
    {
        return;
    }

    DeactivateActor(Actor);
    AvailableActors.Add(Actor);
    OnActorReturned.Broadcast(Actor);
}

void UActorPool::Warmup(int32 Count)
{
    UWorld* World = GetWorld();
    if (World)
    {
        CachedWorld = World;
    }

    const int32 Remaining = MaxCapacity - TotalAllocated;
    const int32 ToCreate = FMath::Min(Count, Remaining);
    
    for (int32 i = 0; i < ToCreate; ++i)
    {
        AActor* Actor = SpawnNewActor();
        if (Actor)
        {
            AvailableActors.Add(Actor);
        }
    }
}

void UActorPool::Clear()
{
    UWorld* World = CachedWorld ? CachedWorld : GetWorld();
    
    for (AActor* Actor : AvailableActors)
    {
        if (IsValid(Actor))
        {
            if (World)
            {
                World->DestroyActor(Actor);
            }
        }
    }
    
    AvailableActors.Empty();
    TotalAllocated = 0;
}
