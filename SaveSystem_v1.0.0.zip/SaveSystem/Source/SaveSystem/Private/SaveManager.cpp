#include "SaveManager.h"
#include "GameFramework/SaveGame.h"
#include "Engine/GameViewportClient.h"
#include "Engine/Texture2D.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Misc/DateTime.h"
#include "HAL/PlatformFileManager.h"
#include "Serialization/MemoryReader.h"
#include "Serialization/MemoryWriter.h"
#include "Serialization/ObjectAndNameAsStringProxyArchive.h"
#include "ImageUtils.h"
#include "IImageWrapper.h"
#include "IImageWrapperModule.h"
#include "Modules/ModuleManager.h"
#include "Misc/Compression.h"

void USaveManager::Initialize(FSubsystemCollectionBase& Collection)
{
    Super::Initialize(Collection);
    const FString SaveDir = GetSaveDirectory();
    IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
    if (!PlatformFile.DirectoryExists(*SaveDir))
    {
        PlatformFile.CreateDirectoryTree(*SaveDir);
    }
}

void USaveManager::Deinitialize()
{
    Super::Deinitialize();
}

FString USaveManager::GetSaveDirectory() const
{
    return FPaths::ProjectSavedDir() / TEXT("SaveGames");
}

FString USaveManager::GetSlotFilePath(const FString& SlotName, bool bScreenshot) const
{
    const FString Ext = bScreenshot ? TEXT(".png") : TEXT(".sav");
    return GetSaveDirectory() / (SlotName + Ext);
}

FString USaveManager::GetSlotInfoPath(const FString& SlotName) const
{
    return GetSaveDirectory() / (SlotName + TEXT(".json"));
}

void USaveManager::WriteSlotInfo(const FSaveSlotInfo& Info)
{
    const FString Path = GetSlotInfoPath(Info.SlotName);
    TSharedPtr<FJsonObject> JsonObj = MakeShareable(new FJsonObject);
    JsonObj->SetStringField(TEXT("SlotName"), Info.SlotName);
    JsonObj->SetStringField(TEXT("SaveDate"), Info.SaveDate.ToString());
    JsonObj->SetNumberField(TEXT("SaveVersion"), Info.SaveVersion);
    JsonObj->SetStringField(TEXT("UserMetadata"), Info.UserMetadata);
    JsonObj->SetNumberField(TEXT("DataSizeBytes"), Info.DataSizeBytes);
    JsonObj->SetBoolField(TEXT("bHasScreenshot"), Info.bHasScreenshot);

    FString JsonString;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&JsonString);
    FJsonSerializer::Serialize(JsonObj.ToSharedRef(), Writer);
    FFileHelper::SaveStringToFile(JsonString, *Path);
}

void USaveManager::SaveToSlot(const FString& SlotName, USaveGame* SaveData, const FString& Metadata)
{
    if (!SaveData)
    {
        OnSaveCompleted.Broadcast(ESaveSlotResult::InvalidData);
        return;
    }

    if (SaveSlots.Num() >= MaxSaveSlots && !SaveSlots.Contains(SlotName))
    {
        OnSaveCompleted.Broadcast(ESaveSlotResult::FileWriteFailed);
        return;
    }

    OnSaveProgress.Broadcast(0.0f);

    TArray<uint8> RawData;
    FMemoryWriter MemoryWriter(RawData, true);
    FObjectAndNameAsStringProxyArchive Ar(MemoryWriter, false);
    Ar.ArIsSaveGame = true;
    SaveData->Serialize(Ar);

    OnSaveProgress.Broadcast(0.5f);

    TArray<uint8> FinalData = bUseCompression ? CompressData(RawData) : RawData;
    const FString FilePath = GetSlotFilePath(SlotName);

    if (!FFileHelper::SaveArrayToFile(FinalData, *FilePath))
    {
        OnSaveCompleted.Broadcast(ESaveSlotResult::FileWriteFailed);
        return;
    }

    OnSaveProgress.Broadcast(0.9f);

    FSaveSlotInfo Info;
    Info.SlotName = SlotName;
    Info.SaveDate = FDateTime::Now();
    Info.SaveVersion = SaveVersion;
    Info.UserMetadata = Metadata;
    Info.DataSizeBytes = FinalData.Num();
    Info.bHasScreenshot = FPlatformFileManager::Get().GetPlatformFile().FileExists(*GetSlotFilePath(SlotName, true));

    SaveSlots.Add(SlotName, Info);
    WriteSlotInfo(Info);

    OnSaveProgress.Broadcast(1.0f);
    OnSaveCompleted.Broadcast(ESaveSlotResult::Success);
}

void USaveManager::LoadFromSlot(const FString& SlotName)
{
    const FString FilePath = GetSlotFilePath(SlotName);

    TArray<uint8> FileData;
    if (!FFileHelper::LoadFileToArray(FileData, *FilePath))
    {
        OnLoadCompleted.Broadcast(ESaveSlotResult::SlotNotFound, nullptr);
        return;
    }

    TArray<uint8> RawData = bUseCompression ? DecompressData(FileData) : FileData;
    if (RawData.Num() == 0 && bUseCompression)
    {
        OnLoadCompleted.Broadcast(ESaveSlotResult::CompressionFailed, nullptr);
        return;
    }

    USaveGame* LoadedGame = NewObject<USaveGame>(this);
    FMemoryReader MemoryReader(RawData, true);
    FObjectAndNameAsStringProxyArchive Ar(MemoryReader, true);
    Ar.ArIsSaveGame = true;
    LoadedGame->Serialize(Ar);

    OnLoadCompleted.Broadcast(ESaveSlotResult::Success, LoadedGame);
}

void USaveManager::DeleteSlot(const FString& SlotName)
{
    IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();

    PlatformFile.DeleteFile(*GetSlotFilePath(SlotName));
    PlatformFile.DeleteFile(*GetSlotFilePath(SlotName, true));
    PlatformFile.DeleteFile(*GetSlotInfoPath(SlotName));

    SaveSlots.Remove(SlotName);
}

TArray<FSaveSlotInfo> USaveManager::GetAllSaveSlots() const
{
    TArray<FSaveSlotInfo> Result;
    SaveSlots.GenerateValueArray(Result);
    Result.Sort([](const FSaveSlotInfo& A, const FSaveSlotInfo& B) {
        return A.SaveDate > B.SaveDate;
    });
    return Result;
}

bool USaveManager::DoesSlotExist(const FString& SlotName) const
{
    return SaveSlots.Contains(SlotName);
}

FSaveSlotInfo USaveManager::GetSlotInfo(const FString& SlotName) const
{
    if (const FSaveSlotInfo* Found = SaveSlots.Find(SlotName))
    {
        return *Found;
    }
    FSaveSlotInfo Empty;
    Empty.SlotName = SlotName;
    return Empty;
}

void USaveManager::CaptureScreenshotForSlot(const FString& SlotName)
{
    UGameViewportClient* ViewportClient = nullptr;
    if (const UGameInstance* GI = GetGameInstance())
    {
        ViewportClient = GI->GetGameViewportClient();
    }

    if (!ViewportClient)
    {
        OnScreenshotReady.Broadcast(nullptr);
        return;
    }

    FViewport* Viewport = ViewportClient->Viewport;
    if (!Viewport)
    {
        OnScreenshotReady.Broadcast(nullptr);
        return;
    }

    TArray<FColor> Bitmap;
    int32 Width, Height;
    if (!Viewport->ReadPixels(Bitmap, FReadSurfaceDataFlags(), FIntRect(0, 0, Viewport->GetSizeXY().X, Viewport->GetSizeXY().Y)))
    {
        OnScreenshotReady.Broadcast(nullptr);
        return;
    }

    Width = Viewport->GetSizeXY().X;
    Height = Viewport->GetSizeXY().Y;

    IImageWrapperModule& ImageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>(FName("ImageWrapper"));
    TSharedPtr<IImageWrapper> ImageWrapper = ImageWrapperModule.CreateImageWrapper(EImageFormat::PNG);

    if (ImageWrapper.IsValid() && ImageWrapper->SetRaw(Bitmap.GetData(), Bitmap.Num() * sizeof(FColor), Width, Height, ERGBFormat::BGRA, 8))
    {
        const TArray64<uint8>& PngData = ImageWrapper->GetCompressed();
        const FString Path = GetSlotFilePath(SlotName, true);
        FFileHelper::SaveArrayToFile(TArray<uint8>(PngData.GetData(), PngData.Num()), *Path);

        UTexture2D* Tex = FImageUtils::CreateTexture2D(Width, Height, Bitmap, this, TEXT("SaveScreenshot"), EObjectFlags::RF_Transient, FCreateTexture2DParameters());
        OnScreenshotReady.Broadcast(Tex);

        if (SaveSlots.Contains(SlotName))
        {
            SaveSlots[SlotName].bHasScreenshot = true;
            WriteSlotInfo(SaveSlots[SlotName]);
        }
        return;
    }

    OnScreenshotReady.Broadcast(nullptr);
}

void USaveManager::LoadScreenshotForSlot(const FString& SlotName)
{
    const FString Path = GetSlotFilePath(SlotName, true);
    UTexture2D* Tex = FImageUtils::ImportFileAsTexture2D(Path);
    OnScreenshotReady.Broadcast(Tex);
}

void USaveManager::SetMaxSlots(int32 Max)
{
    MaxSaveSlots = FMath::Clamp(Max, 1, 999);
}

void USaveManager::SetCompressSaves(bool bCompress)
{
    bUseCompression = bCompress;
}

TArray<uint8> USaveManager::CompressData(const TArray<uint8>& RawData) const
{
    int64 CompressedBufSize = FCompression::CompressMemoryBound(NAME_Zlib, RawData.Num());
    TArray<uint8> CompressedBuf;
    CompressedBuf.SetNumUninitialized(CompressedBufSize);
    int64 CompressedSize = CompressedBufSize;
    
    if (FCompression::CompressMemory(NAME_Zlib, CompressedBuf.GetData(), CompressedSize, RawData.GetData(), RawData.Num()))
    {
        // Prepend uncompressed size as 4-byte header for decompression
        TArray<uint8> Out;
        int32 UncompressedSize = RawData.Num();
        Out.Append((uint8*)&UncompressedSize, sizeof(int32));
        Out.Append(CompressedBuf.GetData(), CompressedSize);
        return Out;
    }
    
    // Fallback: store uncompressed with size header
    TArray<uint8> Out;
    int32 UncompressedSize = RawData.Num();
    Out.Append((uint8*)&UncompressedSize, sizeof(int32));
    Out.Append(RawData);
    return Out;
}

TArray<uint8> USaveManager::DecompressData(const TArray<uint8>& CompressedData) const
{
    if (CompressedData.Num() < 4)
    {
        return TArray<uint8>();
    }
    
    int32 UncompressedSize = *(int32*)CompressedData.GetData();
    if (UncompressedSize <= 0 || UncompressedSize > 100 * 1024 * 1024) // Sanity: max 100MB
    {
        return TArray<uint8>();
    }
    
    TArray<uint8> Result;
    Result.SetNumUninitialized(UncompressedSize);
    
    if (FCompression::UncompressMemory(NAME_Zlib, Result.GetData(), UncompressedSize,
        CompressedData.GetData() + sizeof(int32), CompressedData.Num() - sizeof(int32)))
    {
        return Result;
    }
    return TArray<uint8>();
}
