#include "SaveSystem.h"
#include "Modules/ModuleManager.h"

void FSaveSystemModule::StartupModule() {}
void FSaveSystemModule::ShutdownModule() {}

IMPLEMENT_MODULE(FSaveSystemModule, SaveSystem)
