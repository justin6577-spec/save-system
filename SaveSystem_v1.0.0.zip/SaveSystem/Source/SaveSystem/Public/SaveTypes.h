#pragma once

#include "CoreMinimal.h"
#include "SaveTypes.generated.h"

UENUM(BlueprintType)
enum class ESaveSlotResult : uint8
{
    Success,
    SlotNotFound,
    SlotEmpty,
    SerializationFailed,
    CompressionFailed,
    FileWriteFailed,
    FileReadFailed,
    ScreenshotFailed,
    InvalidData
};

USTRUCT(BlueprintType)
struct FSaveSlotInfo
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadOnly)
    FString SlotName;

    UPROPERTY(BlueprintReadOnly)
    FDateTime SaveDate;

    UPROPERTY(BlueprintReadOnly)
    int32 SaveVersion = 0;

    UPROPERTY(BlueprintReadOnly)
    FString UserMetadata;

    UPROPERTY(BlueprintReadOnly)
    int64 DataSizeBytes = 0;

    UPROPERTY(BlueprintReadOnly)
    bool bHasScreenshot = false;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSaveComplete, ESaveSlotResult, Result);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnLoadComplete, ESaveSlotResult, Result, USaveGame*, LoadedData);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSaveProgress, float, Progress);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnScreenshotReady, UTexture2D*, Screenshot);
