#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "SaveTypes.h"
#include "SaveManager.generated.h"

UCLASS(BlueprintType)
class SAVESYSTEM_API USaveManager : public UGameInstanceSubsystem
{
    GENERATED_BODY()

public:
    virtual void Initialize(FSubsystemCollectionBase& Collection) override;
    virtual void Deinitialize() override;

    /* ── Core Save/Load ── */
    UFUNCTION(BlueprintCallable, Category = "Save System")
    void SaveToSlot(const FString& SlotName, USaveGame* SaveData, const FString& Metadata = TEXT(""));

    UFUNCTION(BlueprintCallable, Category = "Save System")
    void LoadFromSlot(const FString& SlotName);

    UFUNCTION(BlueprintCallable, Category = "Save System")
    void DeleteSlot(const FString& SlotName);

    UFUNCTION(BlueprintPure, Category = "Save System")
    TArray<FSaveSlotInfo> GetAllSaveSlots() const;

    UFUNCTION(BlueprintPure, Category = "Save System")
    bool DoesSlotExist(const FString& SlotName) const;

    UFUNCTION(BlueprintPure, Category = "Save System")
    FSaveSlotInfo GetSlotInfo(const FString& SlotName) const;

    /* ── Screenshots ── */
    UFUNCTION(BlueprintCallable, Category = "Save System|Screenshot")
    void CaptureScreenshotForSlot(const FString& SlotName);

    UFUNCTION(BlueprintCallable, Category = "Save System|Screenshot")
    void LoadScreenshotForSlot(const FString& SlotName);

    /* ── Utility ── */
    UFUNCTION(BlueprintCallable, Category = "Save System")
    void SetMaxSlots(int32 Max);

    UFUNCTION(BlueprintCallable, Category = "Save System")
    void SetCompressSaves(bool bCompress);

    UFUNCTION(BlueprintPure, Category = "Save System")
    int32 GetSlotCount() const { return SaveSlots.Num(); }

    /* ── Delegates ── */
    UPROPERTY(BlueprintAssignable)
    FOnSaveComplete OnSaveCompleted;

    UPROPERTY(BlueprintAssignable)
    FOnLoadComplete OnLoadCompleted;

    UPROPERTY(BlueprintAssignable)
    FOnSaveProgress OnSaveProgress;

    UPROPERTY(BlueprintAssignable)
    FOnScreenshotReady OnScreenshotReady;

protected:
    FString GetSaveDirectory() const;
    FString GetSlotFilePath(const FString& SlotName, bool bScreenshot = false) const;
    FString GetSlotInfoPath(const FString& SlotName) const;
    void WriteSlotInfo(const FSaveSlotInfo& Info);
    TArray<uint8> CompressData(const TArray<uint8>& RawData) const;
    TArray<uint8> DecompressData(const TArray<uint8>& CompressedData) const;

    UPROPERTY()
    TMap<FString, FSaveSlotInfo> SaveSlots;

    int32 MaxSaveSlots = 100;
    bool bUseCompression = true;
    int32 SaveVersion = 1;
};
