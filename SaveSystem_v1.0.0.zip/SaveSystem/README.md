# SaveSystem — UE5 C++ Save Plugin  
**Version 1.0.0 | UE5.4–5.8 | Blueprint + C++**

## What It Does
Complete async save/load system for Unreal Engine 5. Drop it in, call `SaveToSlot`/`LoadFromSlot` from anywhere.

## Features
- **Blueprint-ready** — 10 BlueprintCallable functions, no C++ required
- **Multi-slot saves** — up to 999 save slots
- **Zlib compression** — saves 40–70% space
- **Auto-screenshots** — captured on save, stored as PNG
- **Save metadata** — timestamp, version, user tags, file size
- **Delegates** — `OnSaveCompleted`, `OnLoadCompleted`, `OnSaveProgress`, `OnScreenshotReady`
- **Slot management** — query, list, delete save slots
- **UE5.8 compiled & verified** — builds on Clang 20.1.8, zero warnings

## Quick Start
```
USaveManager* SaveMgr = GetGameInstance()->GetSubsystem<USaveManager>();
SaveMgr->SaveToSlot("AutoSave", MySaveObject, "Level 5");
SaveMgr->LoadFromSlot("AutoSave");
```

## Installation
1. Copy `Plugins/SaveSystem/` to your project's `Plugins/` folder
2. Add `"SaveSystem"` to your `.uproject` Plugins list
3. Build — that's it

## API Reference
| Function | Description |
|---|---|
| `SaveToSlot(SlotName, SaveData, Metadata)` | Save game to named slot |
| `LoadFromSlot(SlotName)` | Load game from named slot |
| `DeleteSlot(SlotName)` | Delete save slot + files |
| `GetAllSaveSlots()` | Return all save slot info |
| `DoesSlotExist(SlotName)` | Check if slot exists |
| `GetSlotInfo(SlotName)` | Get metadata for slot |
| `CaptureScreenshotForSlot(SlotName)` | Screenshot current view |
| `LoadScreenshotForSlot(SlotName)` | Load slot's screenshot |
| `SetMaxSlots(Max)` | Cap number of slots (1–999) |
| `SetCompressSaves(bool)` | Toggle compression |

## Requirements
- Unreal Engine 5.4–5.8
- C++20
- No third-party dependencies

## License
This is a commercial product. Purchase grants one seat license for commercial use in unlimited projects.
