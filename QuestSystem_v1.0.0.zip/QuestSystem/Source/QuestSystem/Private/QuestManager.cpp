#include "QuestManager.h"
#include "Engine/GameInstance.h"

bool UQuestManager::StartQuest(FName QuestID)
{
    if (!CanStartQuest(QuestID))
    {
        return false;
    }

    const FQuestDefinition* Def = QuestDefinitions.Find(QuestID);
    if (!Def)
    {
        return false;
    }

    FActiveQuest Quest;
    Quest.QuestID = QuestID;
    Quest.State = EQuestState::Active;
    Quest.Objectives = Def->Objectives;

    ActiveQuests.Add(QuestID, Quest);
    OnQuestStateChanged.Broadcast(QuestID, EQuestState::Active);

    return true;
}

bool UQuestManager::CompleteQuest(FName QuestID)
{
    FActiveQuest* Quest = ActiveQuests.Find(QuestID);
    if (!Quest || Quest->State != EQuestState::Active)
    {
        return false;
    }

    if (!AreObjectivesComplete(*Quest))
    {
        return false;
    }

    Quest->State = EQuestState::Completed;
    CompletedQuests.Add(QuestID);

    const FQuestDefinition* Def = QuestDefinitions.Find(QuestID);
    if (Def)
    {
        GrantReward(Def->Reward);
    }

    OnQuestStateChanged.Broadcast(QuestID, EQuestState::Completed);
    OnQuestCompleted.Broadcast(QuestID);

    return true;
}

bool UQuestManager::FailQuest(FName QuestID)
{
    FActiveQuest* Quest = ActiveQuests.Find(QuestID);
    if (!Quest || Quest->State != EQuestState::Active)
    {
        return false;
    }

    Quest->State = EQuestState::Failed;
    FailedQuests.Add(QuestID);
    OnQuestStateChanged.Broadcast(QuestID, EQuestState::Failed);

    return true;
}

bool UQuestManager::AbandonQuest(FName QuestID)
{
    FActiveQuest* Quest = ActiveQuests.Find(QuestID);
    if (!Quest)
    {
        return false;
    }

    ActiveQuests.Remove(QuestID);
    OnQuestStateChanged.Broadcast(QuestID, EQuestState::Inactive);

    return true;
}

void UQuestManager::AdvanceObjective(FName QuestID, FName TargetID, int32 Count)
{
    FActiveQuest* Quest = ActiveQuests.Find(QuestID);
    if (!Quest || Quest->State != EQuestState::Active)
    {
        return;
    }

    for (int32 i = 0; i < Quest->Objectives.Num(); ++i)
    {
        FQuestObjective& Obj = Quest->Objectives[i];
        if (Obj.TargetID == TargetID && !Obj.IsComplete())
        {
            Obj.CurrentCount = FMath::Min(Obj.CurrentCount + Count, Obj.RequiredCount);
            OnObjectiveProgress.Broadcast(QuestID, i);

            if (AreObjectivesComplete(*Quest))
            {
                // Auto-complete is optional — delegate fires for UI
            }
            return;
        }
    }
}

void UQuestManager::AdvanceObjectiveByType(EObjectiveType Type, FName TargetID, int32 Count)
{
    for (auto& Pair : ActiveQuests)
    {
        FActiveQuest& Quest = Pair.Value;
        if (Quest.State != EQuestState::Active)
        {
            continue;
        }

        for (int32 i = 0; i < Quest.Objectives.Num(); ++i)
        {
            FQuestObjective& Obj = Quest.Objectives[i];
            if (Obj.Type == Type && Obj.TargetID == TargetID && !Obj.IsComplete())
            {
                Obj.CurrentCount = FMath::Min(Obj.CurrentCount + Count, Obj.RequiredCount);
                OnObjectiveProgress.Broadcast(Pair.Key, i);
            }
        }
    }
}

EQuestState UQuestManager::GetQuestState(FName QuestID) const
{
    if (const FActiveQuest* Quest = ActiveQuests.Find(QuestID))
    {
        return Quest->State;
    }
    if (CompletedQuests.Contains(QuestID))
    {
        return EQuestState::Completed;
    }
    if (FailedQuests.Contains(QuestID))
    {
        return EQuestState::Failed;
    }
    return EQuestState::Inactive;
}

TArray<FActiveQuest> UQuestManager::GetActiveQuests() const
{
    TArray<FActiveQuest> Result;
    for (const auto& Pair : ActiveQuests)
    {
        if (Pair.Value.State == EQuestState::Active)
        {
            Result.Add(Pair.Value);
        }
    }
    return Result;
}

bool UQuestManager::IsQuestActive(FName QuestID) const
{
    if (const FActiveQuest* Quest = ActiveQuests.Find(QuestID))
    {
        return Quest->State == EQuestState::Active;
    }
    return false;
}

bool UQuestManager::IsQuestCompleted(FName QuestID) const
{
    return CompletedQuests.Contains(QuestID);
}

float UQuestManager::GetQuestProgress(FName QuestID) const
{
    const FActiveQuest* Quest = ActiveQuests.Find(QuestID);
    if (!Quest || Quest->Objectives.Num() == 0)
    {
        return 0.0f;
    }

    float Total = 0.0f;
    for (const FQuestObjective& Obj : Quest->Objectives)
    {
        Total += Obj.GetProgress();
    }
    return Total / Quest->Objectives.Num();
}

bool UQuestManager::CanStartQuest(FName QuestID) const
{
    if (ActiveQuests.Contains(QuestID))
    {
        return false;
    }

    const FQuestDefinition* Def = QuestDefinitions.Find(QuestID);
    if (!Def)
    {
        return false;
    }

    if (!Def->PrerequisiteQuestID.IsNone() && !CompletedQuests.Contains(Def->PrerequisiteQuestID))
    {
        return false;
    }

    if (!Def->bIsRepeatable && CompletedQuests.Contains(QuestID))
    {
        return false;
    }

    return true;
}

TArray<FName> UQuestManager::GetAvailableQuests() const
{
    TArray<FName> Result;
    for (const auto& Pair : QuestDefinitions)
    {
        if (CanStartQuest(Pair.Key))
        {
            Result.Add(Pair.Key);
        }
    }
    return Result;
}

void UQuestManager::RegisterQuest(FName QuestID, const FQuestDefinition& Definition)
{
    QuestDefinitions.Add(QuestID, Definition);
}

void UQuestManager::GrantReward(const FQuestReward& Reward)
{
    // Rewards are dispatched via delegate — game code handles actual currency/XP/items
    // This keeps the plugin decoupled from any specific inventory/currency system
}

bool UQuestManager::AreObjectivesComplete(const FActiveQuest& Quest) const
{
    for (const FQuestObjective& Obj : Quest.Objectives)
    {
        if (!Obj.IsComplete())
        {
            return false;
        }
    }
    return true;
}