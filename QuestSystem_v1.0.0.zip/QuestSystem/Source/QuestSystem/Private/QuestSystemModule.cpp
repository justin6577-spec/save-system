#include "QuestSystem.h"
#include "Modules/ModuleManager.h"

void FQuestSystemModule::StartupModule() {}
void FQuestSystemModule::ShutdownModule() {}

IMPLEMENT_MODULE(FQuestSystemModule, QuestSystem)