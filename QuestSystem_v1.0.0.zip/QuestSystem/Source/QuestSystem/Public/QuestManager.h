#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "QuestSystemTypes.h"
#include "QuestManager.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnQuestStateChanged, FName, QuestID, EQuestState, NewState);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnObjectiveProgress, FName, QuestID, int32, ObjectiveIndex);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnQuestCompleted, FName, QuestID);

UCLASS(BlueprintType)
class QUESTSYSTEM_API UQuestManager : public UGameInstanceSubsystem
{
    GENERATED_BODY()

public:
    UPROPERTY(BlueprintAssignable, Category="Quest System")
    FOnQuestStateChanged OnQuestStateChanged;

    UPROPERTY(BlueprintAssignable, Category="Quest System")
    FOnObjectiveProgress OnObjectiveProgress;

    UPROPERTY(BlueprintAssignable, Category="Quest System")
    FOnQuestCompleted OnQuestCompleted;

    UFUNCTION(BlueprintCallable, Category="Quest System")
    bool StartQuest(FName QuestID);

    UFUNCTION(BlueprintCallable, Category="Quest System")
    bool CompleteQuest(FName QuestID);

    UFUNCTION(BlueprintCallable, Category="Quest System")
    bool FailQuest(FName QuestID);

    UFUNCTION(BlueprintCallable, Category="Quest System")
    bool AbandonQuest(FName QuestID);

    UFUNCTION(BlueprintCallable, Category="Quest System")
    void AdvanceObjective(FName QuestID, FName TargetID, int32 Count = 1);

    UFUNCTION(BlueprintCallable, Category="Quest System")
    void AdvanceObjectiveByType(EObjectiveType Type, FName TargetID, int32 Count = 1);

    UFUNCTION(BlueprintPure, Category="Quest System")
    EQuestState GetQuestState(FName QuestID) const;

    UFUNCTION(BlueprintPure, Category="Quest System")
    TArray<FActiveQuest> GetActiveQuests() const;

    UFUNCTION(BlueprintPure, Category="Quest System")
    bool IsQuestActive(FName QuestID) const;

    UFUNCTION(BlueprintPure, Category="Quest System")
    bool IsQuestCompleted(FName QuestID) const;

    UFUNCTION(BlueprintPure, Category="Quest System")
    float GetQuestProgress(FName QuestID) const;

    UFUNCTION(BlueprintCallable, Category="Quest System")
    bool CanStartQuest(FName QuestID) const;

    UFUNCTION(BlueprintCallable, Category="Quest System")
    TArray<FName> GetAvailableQuests() const;

    UFUNCTION(BlueprintCallable, Category="Quest System")
    void RegisterQuest(FName QuestID, const FQuestDefinition& Definition);

protected:
    UPROPERTY()
    TMap<FName, FQuestDefinition> QuestDefinitions;

    UPROPERTY()
    TMap<FName, FActiveQuest> ActiveQuests;

    UPROPERTY()
    TSet<FName> CompletedQuests;

    UPROPERTY()
    TSet<FName> FailedQuests;

    void GrantReward(const FQuestReward& Reward);
    bool AreObjectivesComplete(const FActiveQuest& Quest) const;
};