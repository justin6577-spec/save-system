#pragma once

#include "CoreMinimal.h"
#include "QuestSystemTypes.generated.h"

UENUM(BlueprintType)
enum class EQuestState : uint8
{
    Inactive UMETA(DisplayName="Inactive"),
    Active UMETA(DisplayName="Active"),
    Completed UMETA(DisplayName="Completed"),
    Failed UMETA(DisplayName="Failed")
};

UENUM(BlueprintType)
enum class EObjectiveType : uint8
{
    Collect UMETA(DisplayName="Collect Items"),
    Kill UMETA(DisplayName="Kill Enemies"),
    Reach UMETA(DisplayName="Reach Location"),
    Interact UMETA(DisplayName="Interact With"),
    Custom UMETA(DisplayName="Custom")
};

USTRUCT(BlueprintType)
struct QUESTSYSTEM_API FQuestObjective
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    FText Description;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    EObjectiveType Type = EObjectiveType::Custom;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    int32 RequiredCount = 1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    int32 CurrentCount = 0;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    FName TargetID;

    bool IsComplete() const { return CurrentCount >= RequiredCount; }
    float GetProgress() const { return RequiredCount > 0 ? (float)CurrentCount / RequiredCount : 0.0f; }
};

USTRUCT(BlueprintType)
struct QUESTSYSTEM_API FQuestReward
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    int32 Experience = 0;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    int32 Currency = 0;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    FName ItemID;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    int32 ItemCount = 0;
};

USTRUCT(BlueprintType)
struct QUESTSYSTEM_API FQuestDefinition : public FTableRowBase
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    FText QuestName;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    FText Description;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    TArray<FQuestObjective> Objectives;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    FQuestReward Reward;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    FName PrerequisiteQuestID;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Quest")
    bool bIsRepeatable = false;
};

USTRUCT(BlueprintType)
struct QUESTSYSTEM_API FActiveQuest
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadOnly, Category="Quest")
    FName QuestID;

    UPROPERTY(BlueprintReadOnly, Category="Quest")
    EQuestState State = EQuestState::Inactive;

    UPROPERTY(BlueprintReadOnly, Category="Quest")
    TArray<FQuestObjective> Objectives;
};