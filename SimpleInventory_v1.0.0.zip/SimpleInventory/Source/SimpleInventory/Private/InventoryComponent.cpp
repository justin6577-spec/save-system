#include "InventoryComponent.h"

EInventoryResult UInventoryComponent::AddItem(TSubclassOf<UItemData> ItemClass, int32 Count)
{
    if (!ItemClass || Count <= 0) return EInventoryResult::InvalidItem;
    UItemData* Default = ItemClass.GetDefaultObject();
    if (!Default) return EInventoryResult::InvalidItem;

    // Try stacking on existing slot
    int32 ExistingIdx = FindSlotIndex(ItemClass);
    if (ExistingIdx >= 0)
    {
        int32 NewTotal = Slots[ExistingIdx].Count + Count;
        if (NewTotal <= Default->MaxStack)
        {
            Slots[ExistingIdx].Count = NewTotal;
            OnInventoryChanged.Broadcast();
            return EInventoryResult::Success;
        }
    }

    // Try new slot
    int32 EmptyIdx = FindFirstEmptySlot();
    if (EmptyIdx < 0) return EInventoryResult::NoSpace;

    FInventorySlot NewSlot;
    NewSlot.ItemClass = ItemClass;
    NewSlot.Count = FMath::Min(Count, Default->MaxStack);
    Slots[EmptyIdx] = NewSlot;
    OnInventoryChanged.Broadcast();
    return EInventoryResult::Success;
}

EInventoryResult UInventoryComponent::RemoveItem(TSubclassOf<UItemData> ItemClass, int32 Count)
{
    int32 Idx = FindSlotIndex(ItemClass);
    if (Idx < 0) return EInventoryResult::NotFound;
    if (Slots[Idx].Count < Count) return EInventoryResult::NotFound;

    Slots[Idx].Count -= Count;
    if (Slots[Idx].Count <= 0) Slots[Idx] = FInventorySlot();
    OnInventoryChanged.Broadcast();
    return EInventoryResult::Success;
}

bool UInventoryComponent::HasItem(TSubclassOf<UItemData> ItemClass, int32 Count) const
{
    int32 Idx = FindSlotIndex(ItemClass);
    return Idx >= 0 && Slots[Idx].Count >= Count;
}

int32 UInventoryComponent::GetItemCount(TSubclassOf<UItemData> ItemClass) const
{
    int32 Idx = FindSlotIndex(ItemClass);
    return Idx >= 0 ? Slots[Idx].Count : 0;
}

int32 UInventoryComponent::FindSlotIndex(TSubclassOf<UItemData> ItemClass) const
{
    for (int32 i = 0; i < Slots.Num(); ++i)
        if (Slots[i].ItemClass == ItemClass && Slots[i].Count > 0)
            return i;
    return -1;
}

int32 UInventoryComponent::FindFirstEmptySlot() const
{
    for (int32 i = 0; i < Slots.Num(); ++i)
        if (Slots[i].IsEmpty()) return i;
    if (Slots.Num() < MaxSlots)
    {
        const_cast<TArray<FInventorySlot>&>(Slots).Add(FInventorySlot());
        return Slots.Num() - 1;
    }
    return -1;
}

int32 UInventoryComponent::GetUsedSlotCount() const
{
    int32 Count = 0;
    for (const auto& S : Slots) if (!S.IsEmpty()) Count++;
    return Count;
}

void UInventoryComponent::Clear()
{
    Slots.Empty();
    OnInventoryChanged.Broadcast();
}
