#include "SimpleInventory.h"
void FSimpleInventoryModule::StartupModule() {} void FSimpleInventoryModule::ShutdownModule() {}
IMPLEMENT_MODULE(FSimpleInventoryModule, SimpleInventory)
