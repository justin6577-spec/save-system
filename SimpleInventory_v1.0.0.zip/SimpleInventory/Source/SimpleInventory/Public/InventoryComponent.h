#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "InventoryTypes.h"
#include "InventoryComponent.generated.h"

UCLASS(ClassGroup=(Inventory), meta=(BlueprintSpawnableComponent))
class SIMPLEINVENTORY_API UInventoryComponent : public UActorComponent
{
    GENERATED_BODY()
public:
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Inventory") int32 MaxSlots = 24;

    UFUNCTION(BlueprintCallable, Category="Inventory")
    EInventoryResult AddItem(TSubclassOf<UItemData> ItemClass, int32 Count = 1);

    UFUNCTION(BlueprintCallable, Category="Inventory")
    EInventoryResult RemoveItem(TSubclassOf<UItemData> ItemClass, int32 Count = 1);

    UFUNCTION(BlueprintCallable, Category="Inventory")
    bool HasItem(TSubclassOf<UItemData> ItemClass, int32 Count = 1) const;

    UFUNCTION(BlueprintCallable, Category="Inventory")
    int32 GetItemCount(TSubclassOf<UItemData> ItemClass) const;

    UFUNCTION(BlueprintPure, Category="Inventory")
    const TArray<FInventorySlot>& GetSlots() const { return Slots; }

    UFUNCTION(BlueprintPure, Category="Inventory")
    int32 GetUsedSlotCount() const;

    UFUNCTION(BlueprintCallable, Category="Inventory")
    void Clear();

    UPROPERTY(BlueprintAssignable, Category="Inventory|Events")
    FOnInventoryChanged OnInventoryChanged;

private:
    UPROPERTY() TArray<FInventorySlot> Slots;
    int32 FindSlotIndex(TSubclassOf<UItemData> ItemClass) const;
    int32 FindFirstEmptySlot() const;
};
