#pragma once
#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "InventoryTypes.generated.h"

UENUM(BlueprintType)
enum class EItemRarity : uint8 { Common, Uncommon, Rare, Epic, Legendary };

UENUM(BlueprintType)
enum class EInventoryResult : uint8 { Success, NoSpace, NotFound, InvalidItem };

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnInventoryChanged);

USTRUCT(BlueprintType)
struct FInventorySlot
{
    GENERATED_BODY()
    UPROPERTY() TSubclassOf<class UItemData> ItemClass;
    UPROPERTY() int32 Count = 0;
    bool IsEmpty() const { return Count <= 0 || !ItemClass; }
};

UCLASS(BlueprintType)
class SIMPLEINVENTORY_API UItemData : public UPrimaryDataAsset
{
    GENERATED_BODY()
public:
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FText ItemName;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FText Description;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) EItemRarity Rarity = EItemRarity::Common;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) int32 MaxStack = 99;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) UTexture2D* Icon = nullptr;
};
