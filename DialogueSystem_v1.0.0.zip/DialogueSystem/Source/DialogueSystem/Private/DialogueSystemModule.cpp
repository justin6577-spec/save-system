#include "DialogueSystem.h"
#include "Modules/ModuleManager.h"
IMPLEMENT_MODULE(FDialogueSystemModule, DialogueSystem)