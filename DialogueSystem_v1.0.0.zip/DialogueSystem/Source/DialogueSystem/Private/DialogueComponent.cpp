#include "DialogueComponent.h"
#include "Engine/DataTable.h"

void UDialogueComponent::StartDialogue(UDataTable* DialogueTable, FName StartNodeID)
{
    if (!DialogueTable || bInDialogue) return;

    CurrentTable = DialogueTable;
    bInDialogue = true;
    OnDialogueStarted.Broadcast(StartNodeID);
    ShowNode(StartNodeID);
}

void UDialogueComponent::SelectResponse(int32 ResponseIndex)
{
    if (!bInDialogue || !CurrentTable) return;

    FDialogueNode* Node = CurrentTable->FindRow<FDialogueNode>(CurrentNodeID, TEXT("DialogueComponent"));
    if (!Node || ResponseIndex < 0 || ResponseIndex >= Node->Responses.Num()) return;

    const FDialogueResponse& Response = Node->Responses[ResponseIndex];

    if (Response.EventToFire.IsNone())
    {
        FireEvent(Response.EventToFire);
    }

    if (Response.NextNodeID.IsNone())
    {
        EndDialogue();
    }
    else
    {
        ShowNode(Response.NextNodeID);
    }
}

void UDialogueComponent::EndDialogue()
{
    bInDialogue = false;
    CurrentTable = nullptr;
    CurrentNodeID = NAME_None;
    OnDialogueEnded.Broadcast();
}

void UDialogueComponent::SkipToNode(FName NodeID)
{
    if (!bInDialogue) return;
    ShowNode(NodeID);
}

void UDialogueComponent::SetCondition(FName Key, int32 Value)
{
    Conditions.Add(Key, Value);
}

int32 UDialogueComponent::GetCondition(FName Key) const
{
    const int32* Val = Conditions.Find(Key);
    return Val ? *Val : 0;
}

void UDialogueComponent::ShowNode(FName NodeID)
{
    if (!CurrentTable) return;

    FDialogueNode* Node = CurrentTable->FindRow<FDialogueNode>(NodeID, TEXT("DialogueComponent"));
    if (!Node)
    {
        EndDialogue();
        return;
    }

    CurrentNodeID = NodeID;

    FDialogueSnapshot Snapshot;
    Snapshot.SpeakerName = Node->SpeakerName;
    Snapshot.DialogueText = Node->DialogueText;
    Snapshot.bIsEndNode = Node->bIsEndNode;

    // Filter responses by conditions
    for (const FDialogueResponse& Resp : Node->Responses)
    {
        if (CheckConditions(Resp.Conditions))
        {
            Snapshot.AvailableResponses.Add(Resp);
        }
    }

    OnDialogueNode.Broadcast(Snapshot);

    // Auto-advance if no responses and has auto-next
    if (Snapshot.AvailableResponses.Num() == 0)
    {
        if (!Node->AutoNextNodeID.IsNone())
        {
            ShowNode(Node->AutoNextNodeID);
        }
        else if (Node->bIsEndNode)
        {
            EndDialogue();
        }
    }
}

bool UDialogueComponent::CheckConditions(const TArray<FDialogueCondition>& RequiredConditions) const
{
    for (const FDialogueCondition& Cond : RequiredConditions)
    {
        const int32* Val = Conditions.Find(Cond.ConditionKey);
        if (!Val || *Val < Cond.RequiredValue)
        {
            return false;
        }
    }
    return true;
}

void UDialogueComponent::FireEvent(FName EventName)
{
    // Events are dispatched via BlueprintImplementableEvent or game code
    // The component broadcasts the event name; game code hooks into it
}