#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "DialogueSystemTypes.h"
#include "DialogueComponent.generated.h"

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class DIALOGUESYSTEM_API UDialogueComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UPROPERTY(BlueprintAssignable, Category="Dialogue")
    FOnDialogueStarted OnDialogueStarted;

    UPROPERTY(BlueprintAssignable, Category="Dialogue")
    FOnDialogueNode OnDialogueNode;

    UPROPERTY(BlueprintAssignable, Category="Dialogue")
    FOnDialogueEnded OnDialogueEnded;

    UFUNCTION(BlueprintCallable, Category="Dialogue")
    void StartDialogue(UDataTable* DialogueTable, FName StartNodeID);

    UFUNCTION(BlueprintCallable, Category="Dialogue")
    void SelectResponse(int32 ResponseIndex);

    UFUNCTION(BlueprintCallable, Category="Dialogue")
    void EndDialogue();

    UFUNCTION(BlueprintCallable, Category="Dialogue")
    void SkipToNode(FName NodeID);

    UFUNCTION(BlueprintPure, Category="Dialogue")
    bool IsInDialogue() const { return bInDialogue; }

    UFUNCTION(BlueprintCallable, Category="Dialogue")
    void SetCondition(FName Key, int32 Value);

    UFUNCTION(BlueprintPure, Category="Dialogue")
    int32 GetCondition(FName Key) const;

protected:
    UPROPERTY()
    UDataTable* CurrentTable;

    FName CurrentNodeID;
    bool bInDialogue = false;
    TMap<FName, int32> Conditions;

    void ShowNode(FName NodeID);
    bool CheckConditions(const TArray<FDialogueCondition>& RequiredConditions) const;
    void FireEvent(FName EventName);
};