#pragma once

#include "CoreMinimal.h"
#include "DialogueSystemTypes.generated.h"

USTRUCT(BlueprintType)
struct DIALOGUESYSTEM_API FDialogueCondition
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Dialogue")
    FName ConditionKey;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Dialogue")
    int32 RequiredValue = 1;
};

USTRUCT(BlueprintType)
struct DIALOGUESYSTEM_API FDialogueResponse
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Dialogue")
    FText ResponseText;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Dialogue")
    FName NextNodeID;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Dialogue")
    TArray<FDialogueCondition> Conditions;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Dialogue")
    FName EventToFire;
};

USTRUCT(BlueprintType)
struct DIALOGUESYSTEM_API FDialogueNode : public FTableRowBase
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Dialogue")
    FText SpeakerName;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Dialogue")
    FText DialogueText;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Dialogue")
    TArray<FDialogueResponse> Responses;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Dialogue")
    FName AutoNextNodeID;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Dialogue")
    bool bIsEndNode = false;
};

USTRUCT(BlueprintType)
struct DIALOGUESYSTEM_API FDialogueSnapshot
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadOnly, Category="Dialogue")
    FText SpeakerName;

    UPROPERTY(BlueprintReadOnly, Category="Dialogue")
    FText DialogueText;

    UPROPERTY(BlueprintReadOnly, Category="Dialogue")
    TArray<FDialogueResponse> AvailableResponses;

    UPROPERTY(BlueprintReadOnly, Category="Dialogue")
    bool bIsEndNode = false;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnDialogueNode, const FDialogueSnapshot&, Node);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnDialogueEnded);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnDialogueStarted, FName, DialogueID);