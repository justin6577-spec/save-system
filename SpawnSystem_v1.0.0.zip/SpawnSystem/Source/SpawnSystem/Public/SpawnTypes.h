#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "SpawnTypes.generated.h"

UENUM(BlueprintType)
enum class ESpawnPattern : uint8
{
    Random UMETA(DisplayName="Random Points"),
    Sequential UMETA(DisplayName="Sequential"),
    Circle UMETA(DisplayName="Circle Formation"),
    Grid UMETA(DisplayName="Grid Formation")
};

USTRUCT(BlueprintType)
struct SPAWNSYSTEM_API FWaveDefinition : public FTableRowBase
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Spawn")
    TSubclassOf<AActor> ActorClass;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Spawn")
    int32 Count = 5;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Spawn")
    float SpawnInterval = 1.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Spawn")
    float DelayBeforeWave = 0.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Spawn")
    ESpawnPattern Pattern = ESpawnPattern::Random;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Spawn")
    float Radius = 500.0f;
};

USTRUCT(BlueprintType)
struct SPAWNSYSTEM_API FSpawnConfig
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Spawn")
    TArray<FWaveDefinition> Waves;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Spawn")
    bool bLoopWaves = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Spawn")
    bool bAutoStart = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Spawn")
    int32 MaxActiveActors = 50;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnWaveStarted, int32, WaveIndex);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnWaveCompleted, int32, WaveIndex);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnAllWavesCompleted);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSpawnActorSpawned, AActor*, SpawnedActor);