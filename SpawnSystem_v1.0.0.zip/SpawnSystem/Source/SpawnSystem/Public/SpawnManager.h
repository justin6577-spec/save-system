#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "SpawnTypes.h"
#include "SpawnManager.generated.h"

UCLASS(BlueprintType)
class SPAWNSYSTEM_API USpawnManager : public UWorldSubsystem
{
    GENERATED_BODY()

public:
    UPROPERTY(BlueprintAssignable, Category="Spawn System")
    FOnWaveStarted OnWaveStarted;

    UPROPERTY(BlueprintAssignable, Category="Spawn System")
    FOnWaveCompleted OnWaveCompleted;

    UPROPERTY(BlueprintAssignable, Category="Spawn System")
    FOnAllWavesCompleted OnAllWavesCompleted;

    UPROPERTY(BlueprintAssignable, Category="Spawn System")
    FOnSpawnActorSpawned OnSpawnActorSpawned;

    UFUNCTION(BlueprintCallable, Category="Spawn System")
    void StartWaves(const FSpawnConfig& Config, FVector Origin);

    UFUNCTION(BlueprintCallable, Category="Spawn System")
    void StopWaves();

    UFUNCTION(BlueprintCallable, Category="Spawn System")
    void PauseWaves();

    UFUNCTION(BlueprintCallable, Category="Spawn System")
    void ResumeWaves();

    UFUNCTION(BlueprintCallable, Category="Spawn System")
    AActor* SpawnSingle(TSubclassOf<AActor> Class, FVector Location, FRotator Rotation = FRotator::ZeroRotator);

    UFUNCTION(BlueprintCallable, Category="Spawn System")
    void SpawnAtPoints(TSubclassOf<AActor> Class, const TArray<FVector>& Points);

    UFUNCTION(BlueprintPure, Category="Spawn System")
    int32 GetCurrentWave() const { return CurrentWaveIndex; }

    UFUNCTION(BlueprintPure, Category="Spawn System")
    int32 GetTotalWaves() const { return CurrentConfig.Waves.Num(); }

    UFUNCTION(BlueprintPure, Category="Spawn System")
    int32 GetActiveSpawnCount() const { return SpawnedActors.Num(); }

    UFUNCTION(BlueprintPure, Category="Spawn System")
    bool IsSpawning() const { return bIsSpawning; }

protected:
    virtual void Deinitialize() override;

private:
    FSpawnConfig CurrentConfig;
    FVector SpawnOrigin;
    int32 CurrentWaveIndex = 0;
    int32 SpawnsInCurrentWave = 0;
    bool bIsSpawning = false;
    bool bIsPaused = false;
    FTimerHandle WaveTimer;
    FTimerHandle SpawnTimer;
    UPROPERTY()
    TArray<AActor*> SpawnedActors;

    void StartNextWave();
    void SpawnNextInWave();
    void CompleteWave();
    TArray<FVector> GenerateSpawnPoints(ESpawnPattern Pattern, int32 Count, float Radius) const;
    void CleanupDestroyedActors();
};