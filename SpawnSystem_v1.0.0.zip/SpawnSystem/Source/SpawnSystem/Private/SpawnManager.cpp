#include "SpawnManager.h"
#include "Engine/World.h"
#include "TimerManager.h"

void USpawnManager::StartWaves(const FSpawnConfig& Config, FVector Origin)
{
    StopWaves();
    CurrentConfig = Config;
    SpawnOrigin = Origin;
    CurrentWaveIndex = 0;
    SpawnsInCurrentWave = 0;
    bIsSpawning = true;
    bIsPaused = false;
    SpawnedActors.Empty();

    StartNextWave();
}

void USpawnManager::StopWaves()
{
    bIsSpawning = false;
    if (UWorld* World = GetWorld())
    {
        World->GetTimerManager().ClearTimer(WaveTimer);
        World->GetTimerManager().ClearTimer(SpawnTimer);
    }
    SpawnedActors.Empty();
}

void USpawnManager::PauseWaves()
{
    bIsPaused = true;
}

void USpawnManager::ResumeWaves()
{
    bIsPaused = false;
}

AActor* USpawnManager::SpawnSingle(TSubclassOf<AActor> Class, FVector Location, FRotator Rotation)
{
    UWorld* World = GetWorld();
    if (!World || !Class)
    {
        return nullptr;
    }

    FActorSpawnParameters Params;
    Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

    AActor* Spawned = World->SpawnActor<AActor>(Class, Location, Rotation, Params);
    if (Spawned)
    {
        SpawnedActors.Add(Spawned);
        OnSpawnActorSpawned.Broadcast(Spawned);
    }
    return Spawned;
}

void USpawnManager::SpawnAtPoints(TSubclassOf<AActor> Class, const TArray<FVector>& Points)
{
    for (const FVector& Pt : Points)
    {
        SpawnSingle(Class, Pt);
    }
}

void USpawnManager::StartNextWave()
{
    if (CurrentWaveIndex >= CurrentConfig.Waves.Num())
    {
        if (CurrentConfig.bLoopWaves)
        {
            CurrentWaveIndex = 0;
        }
        else
        {
            bIsSpawning = false;
            OnAllWavesCompleted.Broadcast();
            return;
        }
    }

    const FWaveDefinition& Wave = CurrentConfig.Waves[CurrentWaveIndex];
    SpawnsInCurrentWave = 0;
    OnWaveStarted.Broadcast(CurrentWaveIndex);

    UWorld* World = GetWorld();
    if (!World) return;

    float Delay = Wave.DelayBeforeWave;
    World->GetTimerManager().SetTimer(WaveTimer, [this]()
    {
        if (!bIsSpawning) return;
        SpawnNextInWave();
    }, Delay, false);
}

void USpawnManager::SpawnNextInWave()
{
    if (!bIsSpawning || bIsPaused) return;

    FWaveDefinition& Wave = CurrentConfig.Waves[CurrentWaveIndex];
    if (!Wave.ActorClass) return;

    CleanupDestroyedActors();

    if (SpawnedActors.Num() >= CurrentConfig.MaxActiveActors)
    {
        // Wait and retry
        UWorld* World = GetWorld();
        if (World)
        {
            World->GetTimerManager().SetTimer(SpawnTimer, this, &USpawnManager::SpawnNextInWave, 0.5f, false);
        }
        return;
    }

    TArray<FVector> Points = GenerateSpawnPoints(Wave.Pattern, 1, Wave.Radius);
    if (Points.Num() > 0)
    {
        SpawnSingle(Wave.ActorClass, SpawnOrigin + Points[0]);
    }

    SpawnsInCurrentWave++;

    if (SpawnsInCurrentWave < Wave.Count)
    {
        UWorld* World = GetWorld();
        if (World)
        {
            World->GetTimerManager().SetTimer(SpawnTimer, this, &USpawnManager::SpawnNextInWave, Wave.SpawnInterval, false);
        }
    }
    else
    {
        CompleteWave();
    }
}

void USpawnManager::CompleteWave()
{
    OnWaveCompleted.Broadcast(CurrentWaveIndex);
    CurrentWaveIndex++;
    StartNextWave();
}

TArray<FVector> USpawnManager::GenerateSpawnPoints(ESpawnPattern Pattern, int32 Count, float Radius) const
{
    TArray<FVector> Points;

    switch (Pattern)
    {
    case ESpawnPattern::Random:
        for (int32 i = 0; i < Count; ++i)
        {
            float Angle = FMath::FRandRange(0.0f, PI * 2.0f);
            float Dist = FMath::FRandRange(0.0f, Radius);
            Points.Add(FVector(FMath::Cos(Angle) * Dist, FMath::Sin(Angle) * Dist, 0.0f));
        }
        break;

    case ESpawnPattern::Circle:
        for (int32 i = 0; i < Count; ++i)
        {
            float Angle = (PI * 2.0f * i) / Count;
            Points.Add(FVector(FMath::Cos(Angle) * Radius, FMath::Sin(Angle) * Radius, 0.0f));
        }
        break;

    case ESpawnPattern::Grid:
        {
            int32 Side = FMath::CeilToInt(FMath::Sqrt((float)Count));
            float Step = (Radius * 2.0f) / Side;
            for (int32 i = 0; i < Count; ++i)
            {
                int32 Row = i / Side;
                int32 Col = i % Side;
                Points.Add(FVector(Col * Step - Radius, Row * Step - Radius, 0.0f));
            }
        }
        break;

    case ESpawnPattern::Sequential:
    default:
        for (int32 i = 0; i < Count; ++i)
        {
            Points.Add(FVector(i * 100.0f, 0.0f, 0.0f));
        }
        break;
    }

    return Points;
}

void USpawnManager::CleanupDestroyedActors()
{
    SpawnedActors.RemoveAll([](AActor* A) { return !IsValid(A); });
}

void USpawnManager::Deinitialize()
{
    StopWaves();
    Super::Deinitialize();
}