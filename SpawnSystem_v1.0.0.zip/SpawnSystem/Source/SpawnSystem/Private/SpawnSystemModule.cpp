#include "SpawnSystem.h"
#include "Modules/ModuleManager.h"
IMPLEMENT_MODULE(FSpawnSystemModule, SpawnSystem)