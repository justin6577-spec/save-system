#include "InteractionSystem.h"

void FInteractionSystemModule::StartupModule() {}
void FInteractionSystemModule::ShutdownModule() {}

IMPLEMENT_MODULE(FInteractionSystemModule, InteractionSystem)
